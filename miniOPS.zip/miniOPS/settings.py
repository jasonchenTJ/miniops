###################mysql database setting#####################
#DIALECT = 'mysql'
#DRIVER = 'pymysql'
#USERNAME = 'app_ops'
#PASSWORD = 'admin123_abdD'
#HOST = '192.168.55.180'
#PORT = '3306'
#DATABASE = 'db_mini_ops'
#SQLALCHEMY_DATABASE_URI = '{}+{}://{}:{}@{}:{}/{}?charset=utf8mb4&autocommit=true'.format(
#   DIALECT, DRIVER, USERNAME, PASSWORD, HOST, PORT, DATABASE
#)
###################postgres database setting#####################
# 修改后的 PostgreSQL 配置
DIALECT = 'postgresql'
DRIVER = 'psycopg2'  # 或其他 PostgreSQL 驱动如 pg8000
USERNAME = 'app_ops'  # 你的 PostgreSQL 用户名
PASSWORD = 'admin123_abdD'  # 你的 PostgreSQL 密码
HOST = '192.168.55.180'  # PostgreSQL 服务器地址
PORT = '5432'  # PostgreSQL 默认端口
DATABASE = 'db_mini_ops'  # PostgreSQL 数据库名

# PostgreSQL 连接 URI
SQLALCHEMY_DATABASE_URI = '{}+{}://{}:{}@{}:{}/{}'.format(
    DIALECT, DRIVER, USERNAME, PASSWORD, HOST, PORT, DATABASE
)

SQLALCHEMY_COMMIT_ON_TEARDOWN = True
SQLALCHEMY_TRACK_MODIFICATIONS = True
SQLALCHEMY_POOL_SIZE = 10
SQLALCHEMY_MAX_OVERFLOW = 5
##################session key#####################
SECRET_KEY = 'e4acedd4-c9ed-11ec-8ac0-dcf401d0a568'



